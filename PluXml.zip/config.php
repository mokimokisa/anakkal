<?php
const PLX_CONFIG_PATH = 'data/configuration/';
?>
